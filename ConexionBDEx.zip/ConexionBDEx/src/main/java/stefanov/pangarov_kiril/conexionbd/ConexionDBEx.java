/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package stefanov.pangarov_kiril.conexionbd;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author Kiril_SP
 */
public class ConexionDBEx {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        menu();

    }

    public static void menu() {
        try ( Scanner teclado = new Scanner(System.in)) {
            boolean salida = false;
            while (!salida) {
                System.out.println("Opciones:");
                System.out.println("1. Buscar Nombre");
                System.out.println("2. Lanzar Consulta");
                System.out.println("3. Nuevo Registro");
                System.out.println("4. Eliminar Registro");
                System.out.println("5. Salida");

                System.out.println("Elige tu opción: ");
                int choice = teclado.nextInt();
                teclado.nextLine(); // Para no dejar un espacio en blanco

                switch (choice) {
                    case 1 -> {
                        System.out.println("Dime un nombre: ");
                        String nombre = teclado.nextLine();
                        System.out.println(buscarNombre(nombre.trim()));
                    }
                    case 2 -> {
                        System.out.println("Dime una consulta: ");
                        String consulta = teclado.nextLine();
                        System.out.println(lanzaConsulta(consulta));
                    }
                    case 3 -> {
                        System.out.println("Dime nuevo Registro: ");
                        System.out.println("Dime un nuevo Nombre: ");
                        String nuevoNombre = teclado.nextLine();
                        System.out.println("Dime un nuevo Genero: ");
                        String nuevoGenero = teclado.nextLine();
                        System.out.println("Dime una nueva Fecha de Lanzamiento: ");
                        String nuevaFecha = teclado.nextLine();
                        System.out.println("Dime una nueva Compañia: ");
                        String nuevaCompania = teclado.nextLine();
                        System.out.println("Dime un nuevo Precio: ");
                        float nuevoPrecio = teclado.nextFloat();
                        teclado.nextLine(); // Para no dejar un espacio en blanco
                        System.out.println(nuevoRegistro(nuevoNombre, nuevoGenero, nuevaFecha, nuevaCompania, nuevoPrecio));
                    }
                    case 4 -> {
                        System.out.println("Dime un nombre para eliminar: ");
                        String nombreEliminar = teclado.nextLine();
                        System.out.println(eliminarRegistro(nombreEliminar));
                    }
                    case 5 ->
                        salida = true;
                    default ->
                        System.out.println("Opción Invalida.");
                }
            }

        }
    }

    @SuppressWarnings({"CallToPrintStackTrace", "ConvertToTryWithResources"})
    public static boolean buscarNombre(String nombreJ) {

        boolean salida = false;

        try {

            String QUERY = "select * from Videojuegos where Nombre = ?;";

            Connection conexion = BDConPool.getConnection();
            PreparedStatement sentencia = conexion.prepareStatement(QUERY);
            sentencia.setString(1, nombreJ);
            ResultSet rs = sentencia.executeQuery();

            while (rs.next()) {
                salida = nombreJ.equalsIgnoreCase(rs.getString("Nombre"));
            }

            conexion.close();

            return salida;
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return salida;
    }

    // Se entiende que el que lanza la consulta sabe hacerlo y sabe la base de datos y sus tablas.
    @SuppressWarnings({"CallToPrintStackTrace", "ConvertToTryWithResources"})
    public static String lanzaConsulta(String queryJ) {
        String salida = "";

        try {

            Connection conexion = BDConPool.getConnection();
            PreparedStatement sentencia = conexion.prepareStatement(queryJ);
            ResultSet rs = sentencia.executeQuery();

            while (rs.next()) {

                salida += "\nID: " + rs.getInt("id") + "\n";
                salida += ", Nombre: " + rs.getString("nombre") + "\n";
                salida += ", Genero: " + rs.getString("genero") + "\n";
                salida += ", Fecha de Lanzamiento: " + rs.getDate("fechaLanzamiento") + "\n";
                salida += ", Compañia: " + rs.getString("compañia") + "\n";
                salida += "y Precio: " + rs.getFloat("precio");

            }

            conexion.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return salida;
    }

    @SuppressWarnings({"CallToPrintStackTrace", "ConvertToTryWithResources"})
    public static boolean nuevoRegistro(String nombreJ, String generoJ, String fechaLanJ, String compañiaJ, float precioJ) {

        boolean salida = false;
        try {

            Date fechaL = Date.valueOf(fechaLanJ);
            String queryN = "insert into videojuegos (Nombre, Genero, FechaLanzamiento, Compañia, Precio) values (?, ?, ?, ?, ?);";
            Connection conexion = BDConPool.getConnection();
            PreparedStatement sentencia = conexion.prepareStatement(queryN, PreparedStatement.RETURN_GENERATED_KEYS);
            sentencia.setString(1, nombreJ);
            sentencia.setString(2, generoJ);
            sentencia.setDate(3, fechaL);
            sentencia.setString(4, compañiaJ);
            sentencia.setFloat(5, precioJ);
            sentencia.executeUpdate();
            ResultSet rs = sentencia.getGeneratedKeys();

            while (rs.next()) {
                int claveGenerada = rs.getInt(1);
                System.out.println("Clave generada: " + claveGenerada);
            }

            salida = sentencia.isPoolable();

            conexion.close();

        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return salida;

    }

    @SuppressWarnings({"CallToPrintStackTrace", "ConvertToTryWithResources"})
    public static boolean eliminarRegistro(String nombreJ) {

        boolean salida = false;
        try {

            String queryNE = "select nombre from videojuegos where nombre = ?;";
            String nombreC = null;

            Connection conexion = BDConPool.getConnection();
            PreparedStatement sentencia = conexion.prepareStatement(queryNE);
            sentencia.setString(1, nombreJ);

            ResultSet rs = sentencia.executeQuery();

            while (rs.next()) {

                nombreC = rs.getString("Nombre");

            }

            if (nombreJ.equalsIgnoreCase(nombreC)) {

                String queryE = "delete from videojuegos where nombre = ?";
                sentencia = conexion.prepareStatement(queryE);
                sentencia.setString(1, nombreJ);
                sentencia.executeUpdate();

                salida = true;
            } else {
                salida = false;
            }

            conexion.close();

        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return salida;
    }

}
