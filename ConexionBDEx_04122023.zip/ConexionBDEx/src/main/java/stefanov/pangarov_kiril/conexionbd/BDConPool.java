/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package stefanov.pangarov_kiril.conexionbd;

import java.sql.Connection;
import java.sql.SQLException;
import oracle.ucp.jdbc.PoolDataSource;
import oracle.ucp.jdbc.PoolDataSourceFactory;

/**
 *
 * Esta es mi clase que hace la conexión a la base de datos.
 *
 * @author Kiril_SP
 */
public class BDConPool {

    // Datos de la conexión
    private static final PoolDataSource pds = PoolDataSourceFactory.getPoolDataSource();
    private static final String DB_URI = "jdbc:mysql://localhost:3306/jcvd";
    private static final String USER = "kiril";
    private static final String PASS = "12345";

    /**
     *
     * @return @throws SQLException
     */
    
    // Metodo que se invoca cuando se hace la conexión con nuestros datos
    public static Connection getConnection() throws SQLException {

        pds.setConnectionFactoryClassName("com.mysql.cj.jdbc.MysqlDataSource");
        pds.setURL(DB_URI);
        pds.setUser(USER);
        pds.setPassword(PASS);
        pds.setInitialPoolSize(5);

        return pds.getConnection();
    }

}
